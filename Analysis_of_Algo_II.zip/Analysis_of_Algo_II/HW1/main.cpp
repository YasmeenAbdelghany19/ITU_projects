/* @author
Student name: Yasmeen Abdelghany
Student ID: 150190915
Date: 28.03.2023
*/

#include <iostream>
#include <string>
#include <queue>
#include <stack>
#include <vector>
#include <fstream>
#include <sstream>
#include <math.h>
#include <cstring>
#include <chrono>


using namespace std;

class Child
{
public:
    int x;                      // kid's x position
    int y;                      // kid's y position
    int p;                      // kid's strength level

    void init_child(int x, int y, int p)
    {
        this->x = x;
        this->y = y;
        this->p = p;
    }
};

class Graph
{
public:
    int n; //no. of kids
    Graph(int n)
    {
        this->n = n;
    }
    //writes the adjacency matrix in the graph.txt
    void writeGraph(vector<vector<int>> &children)
    {
        ofstream myFile1;
        myFile1.open("graph.txt", ios::out); // ios::out for writing into the file)
        myFile1 << "Graph:" << endl;
        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < n; j++)
            {
                myFile1 << children[i][j] << " ";
            }
            myFile1 << endl;
        }
        myFile1.close();
    }
    
    //creates the adjacency matrix as a graph accorcing to the kids location in the grid
    void adjMatrix(Child *child, vector<vector<int>> &children)
    {
        for (int i = 0; i < n; i++)
        {
            for (int j = i + 1; j < n; j++)
            {
                int distance = pow(child[i].x - child[j].x, 2) + pow(child[i].y - child[j].y, 2);
                if (distance <= child[i].p && distance <= child[j].p)
                {
                    children[i][j] = 1;
                    children[j][i] = 1;
                }
            }
        }
        writeGraph(children);
        
    }

    //writes the bfs.txt
    void writeBFS(int vertices[][2], int destination)
    {
        stack<int> path;
        path.push(destination);
        int parent = vertices[destination][1];
        path.push(parent);
        while (vertices[parent][1] != -1)
        {
            parent = vertices[parent][1];
            path.push(parent);
        }

        ofstream myFile1;
        myFile1.open("bfs.txt", ios::out); // ios::out for writing into the file)
        myFile1 << "BFS:" << endl
                << vertices[destination][0] << " "; //the destination node's distance from the source node is the length of the shortest path
        string sep = "";
        while (!path.empty())
        {
            myFile1 << sep << path.top();
            path.pop();
            sep = "->";
        }
        myFile1 << endl;
        myFile1.close();
    }

    //traverses the graph using BFS
    void BFS(int source, int destination, vector<vector<int>> &children)
    {
        int vertices[n][2]; //[node][0] represents nth edges from the source, [node][1] represents the parent node
        memset(vertices, -1, sizeof(vertices)); //sets all elements to -1
        queue<int> nextNodes; // tracks the order in which the nodes are visited

        vertices[source][0] = 0; // start node is the start of the path
        nextNodes.push(source);

        while (!nextNodes.empty())
        {
            //dequeue repeatedly and visit its neighbors 
            int parent = nextNodes.front(); 
            nextNodes.pop();

            for (int i = 0; i < n; i++)
            {                
                //if the jth kid is unvisisted, update its path and distance from the source node and push it to the queue
                if (children[parent][i] && vertices[i][0] == -1) 
                {
                    nextNodes.push(i);
                    vertices[i][0] = vertices[parent][0] + 1;
                    vertices[i][1] = parent;
                }
            }
        }

        writeBFS(vertices, destination);
    }

    //writes the cycle path to dfs.txt
    void writeCycle(int node, int nextNode, int vertices[][2], ofstream &myFile1)  
    {
        stack<int> path;
        int pathLength = 0;
        //start from destination vertex and follow the parent nodes backward until reaching the source node to track the path
        path.push(nextNode);
        for (int j = node; j != nextNode; j = vertices[j][1])
        {
            path.push(j);
            pathLength++;
        }
        pathLength++;
        path.push(nextNode);

        myFile1 << "DFS:" << endl
                << pathLength << " ";
        string sep = "";
        while (!path.empty())
        {
            myFile1 << sep << path.top();
            path.pop();
            sep = "->";
        }
    }

    //traverses the graph using BFS
    bool dfsTraversal(vector<vector<int>> &children, int node, int source, int vertices[][2], ofstream &myFile1)
    {
        vertices[node][0] = 1; //1 represents visited nodes, -1 represents unvisited nodes

        //checks for a cycle - if the neighbor node is the source node but not the parent of the current node
        for (int i = 0; i < n; i++)
        {
            if (children[node][i] && i != vertices[node][1] && i == source)
            {
                // cycle found!
                writeCycle(node, i, vertices, myFile1);

                return true;
            }
        }
        //next node to be chosen is the first unvisited neighbor node
        for (int i = 0; i < n; i++)
        {
            if (children[node][i] &&  vertices[i][0] == -1)
            {
                vertices[i][1] = node;
                if (dfsTraversal(children, i, source, vertices, myFile1))
                {
                    return true;
                }
            }
        }
        return false;
    }
    
    //initiates graph traversal, if cycle is not found, it writes to dfs.txt -1
    void DFS(int source, vector<vector<int>> &children)
    {
        ofstream myFile1;
        myFile1.open("dfs.txt", ios::out); // ios::out for writing into the file)
        int vertices[n][2];    //[node][0] represents visited n, [node][1] represents the parent node
        memset(vertices, -1, sizeof(vertices));
        if (!dfsTraversal(children, source, source, vertices, myFile1))
        {
            // cycle not found!!
            myFile1 << "DFS:" << endl
                    << -1 << " ";
        }
        myFile1.close();
    }
};

int main(int argc, char *argv[]) // 
{
    /*
        INSERT ALL YOUR CODE IN HERE!
        Program Compile Command: g++ -std=c++11 -Wall -Werror main.cpp -o main
        Program Run Command: ./main <input.txt>
        Expected input: /graphs/case{$n}/input_{$n}.txt
        Expected output: graph.txt bfs.txt dfs.txt
        Please, try to write clean and readable code. Remember to comment!!
    */

    try
    {
        if (argc < 2)
        {
            throw "You must enter the file name!";
        }
    }
    catch (const exception &e)
    {
        cerr << e.what() << '\n';
    }

    string fileName = argv[1]; // argv[1];"graphs/case9/input_9.txt"
    fstream myFile;
    int n = 0;           // n kids
    int source = 0;      // source kid no.
    int destination = 0; // destination kid no.
    Child *child = NULL;
    //auto begin = chrono::high_resolution_clock::now(); // start clock
    // read from file
    try
    {
        myFile.open(fileName, ios::in); // ios::in for reading from file
        if (myFile.fail())
        {
            throw "Couldn't open/find the file\n";
        }
        myFile >> n >> source >> destination;
        child = new Child[n];

        for (int i = 0; i < n; i++)
        {
            int x, y, p;
            myFile >> x >> y >> p;        // read x, y, and z values from the file
            child[i].init_child(x, y, p); // initialize the i-th element of the array using the parameterized constructor
        }
        myFile.close();
    }
    catch (const char *e)
    {
        cerr << e << endl;
        exit(1);
    }

    Graph graph(n);
    vector<vector<int>> children(n, vector<int>(n)); // represents the graph's adjacency matrix
    graph.adjMatrix(child, children);
    graph.BFS(source, destination, children);
    graph.DFS(source, children);

    delete[] child;
    // auto end = chrono::high_resolution_clock::now(); // end clock
    // double run_time = chrono::duration_cast<chrono::duration<double>>(end - begin).count();
    // cout << "Run Time: " << run_time << endl;
    // cout << "Nodes: " << n << endl;
    exit(0);
}