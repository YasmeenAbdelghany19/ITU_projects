#include <iostream>
#include <bits/stdc++.h>
#include <string>
#include <vector>
#include <fstream>
#include <sstream>
#include <map>
#include <algorithm>
#include <unordered_map>
#include <iomanip>
#include <sys/stat.h>  

using namespace std;
unordered_map<int, int> M; // For WIS 

class Salon
{
public:
    string name;
    vector<int> start;
    vector<int> end;
    int capacity;

    Salon(const string &_name, int _capacity)
        : name(_name), capacity(_capacity) {}

    void addTime(int s, int e)
    {
        start.push_back(s);
        end.push_back(e);
    }
};

class Place
{
public:
    string name;
    int max_capacity;
    vector<Salon> salons;
    vector<int> startDate;
    vector<int> endDate;

    Place(const string &_name, int _max_capacity = 0)
        : name(_name), max_capacity(_max_capacity) {}

    void addSalon(const Salon &salon)
    {
        salons.push_back(salon);
    }
};

class Assets
{
public:
    float price;
    float value;
    string name;
};
/*

                WIS for each salon

*/
// A function to compute the p array for each salons
vector<int> computeTimeP(vector<Salon> &salons)
{
    int n = salons.size();
    vector<int> p(n);
    for (int i = 0; i < n; i++)
    {
        int j = i - 1;
        while (j >= 0 && salons[j].end > salons[i].start)
        {
            j--;
        }
        p[i] = j;
    }
    return p;
}

// A recursive function to compute the Mimal solution for a salons
int computeTimeM(vector<Salon> &salons, vector<int> &p, int j)
{
    if (j == -1)
        return 0;

    int max_weight = max(salons[j].capacity + computeTimeM(salons, p, p[j]), computeTimeM(salons, p, j - 1));
    M[j] = max_weight;
    return max_weight;
}

// A function to print the selected intervals
void findTimeIntervals(ofstream &outputFile, string name, vector<Salon> &salons, vector<int> &p, int j)
{
    if (j == -1)
        return;

    if (salons[j].capacity + M[p[j]] > M[j - 1])
    {
        findTimeIntervals(outputFile, name, salons, p, p[j]);
        for (size_t i = 0; i < salons[j].start.size(); ++i)
        {
            int start_hour = salons[j].start[i] / 60;
            int start_minute = salons[j].start[i] % 60;
            int finish_hour = salons[j].end[i] / 60;
            int finish_minute = salons[j].end[i] % 60;
            outputFile << name << "\t" << salons[j].name << "\t\t" << start_hour << ":" << setw(2) << setfill('0') << start_minute
                       << "\t" << finish_hour << ":" << setw(2) << setfill('0') << finish_minute
                       << endl;
        }
    }
    else
    {
        findTimeIntervals(outputFile, name, salons, p, j - 1);
    }
}

/*

                WIS for each place

*/
// A function to compute the p array for each place
vector<int> computeDateP(vector<Place> &places)
{
    int n = places.size();
    vector<int> p(n);
    for (int i = 0; i < n; i++)
    {
        int j = i - 1;
        while (j >= 0 && places[j].endDate[0] > places[i].startDate[0])
        {
            j--;
        }
        p[i] = j;
    }
    return p;
}

// A recursive function to compute the Mimal solution for a place
int computeDateM(vector<Place> &places, vector<int> &p, int j)
{
    if (j == -1)
        return 0;

    int max_weight = max(places[j].max_capacity + computeDateM(places, p, p[j]), computeDateM(places, p, j - 1));
    M[j] = max_weight;
    return max_weight;
}

// A function to print the selected intervals
void findDateIntervals(ofstream &outputFile, vector<Place> &places, vector<int> &p, int j)
{
    if (j == -1)
        return;

    if (places[j].max_capacity + M[p[j]] > M[j - 1])
    {
        findDateIntervals(outputFile, places, p, p[j]);
        // Print the place name
        outputFile << places[j].name << "\t";

        // Print the start dates and end dates
        for (size_t i = 0; i < places[j].startDate.size(); ++i)
        {
            stringstream start_ss, finish_ss;
            if (places[j].startDate[i] <= 31)
                start_ss << setw(2) << setfill('0') << places[j].startDate[i] << ".05";
            else
                start_ss << setw(2) << setfill('0') << (places[j].startDate[i] - 31) << ".06";
            if (places[j].endDate[i] <= 31)
                finish_ss << setw(2) << setfill('0') << places[j].endDate[i] << ".05";
            else
                finish_ss << setw(2) << setfill('0') << (places[j].endDate[i] - 31) << ".06";

            // Print the start date and end date in "dd.mm" format
            outputFile << start_ss.str() << "\t" << finish_ss.str() << endl;
        }
    }
    else
    {
        findDateIntervals(outputFile, places, p, j - 1);
    }
}


/*

                Reading of the 4 files

*/
// Function to create the case_x folder inside the outputs folder
void createCaseFolder(const string& caseNumber)
{
    stringstream folderPath;
    folderPath << "outputs/case_" << caseNumber;
    string folderName = folderPath.str();

    // Create the case_x folder if it doesn't exist
    #ifdef _WIN32
        _mkdir(folderName.c_str());
    #else
        mkdir(folderName.c_str(), 0777);
    #endif
}

void readCapacityFile(const string &filename, vector<Place> &places)
{
    ifstream capacity_file(filename);
    if (!capacity_file)
    {
        cerr << "Failed to open capacity file." << endl;
        exit(1);
    }

    string line;
    getline(capacity_file, line); // ignore header line

    while (getline(capacity_file, line))
    {
        istringstream iss(line);
        string placeName, salonName;
        int capacity;

        if (!(iss >> placeName >> salonName >> capacity))
        {
            cerr << "Invalid capacity file format." << endl;
            exit(1);
        }

        // Check if the place already exists
        bool placeExists = false;
        for (size_t i = 0; i < places.size(); i++)
        {
            if (places[i].name == placeName)
            {
                places[i].addSalon(Salon(salonName, capacity));
                placeExists = true;
                break;
            }
        }

        // If the place doesn't exist, create a new one and add it to the vector
        if (!placeExists)
        {
            Place newPlace(placeName);
            newPlace.addSalon(Salon(salonName, capacity));
            places.push_back(newPlace);
        }
    }
    capacity_file.close();
}

void readDailyScheduleFile(const string &filename, vector<Place> &places)
{
    ifstream daily_schedule_file(filename);
    if (!daily_schedule_file)
    {
        cerr << "Failed to open daily_schedule file." << endl;
        exit(1);
    }

    string line;
    getline(daily_schedule_file, line); // ignore header line

    while (getline(daily_schedule_file, line))
    {
        istringstream iss(line);
        string placeName, salonName, startAt, endsAt;

        if (!(iss >> placeName >> salonName >> startAt >> endsAt))
        {
            cerr << "Invalid daily_schedule file format." << endl;
            exit(1);
        }

        // Find the corresponding place in the places vector
        Place *place = nullptr;
        for (size_t i = 0; i < places.size(); i++)
        {
            if (places[i].name == placeName)
            {
                place = &places[i];
                break;
            }
        }

        if (place != nullptr)
        {
            // Find the corresponding salon in the place's salons vector
            Salon *salon = nullptr;
            for (size_t i = 0; i < place->salons.size(); i++)
            {
                if (place->salons[i].name == salonName)
                {
                    salon = &place->salons[i];
                    break;
                }
            }

            if (salon != nullptr)
            {
                // Convert start and end times to minutes
                int startTime = stoi(startAt.substr(0, startAt.find(':'))) * 60 + stoi(startAt.substr(startAt.find(':') + 1));
                int endTime = stoi(endsAt.substr(0, endsAt.find(':'))) * 60 + stoi(endsAt.substr(endsAt.find(':') + 1));

                salon->addTime(startTime, endTime);
            }
        }
    }
    daily_schedule_file.close();
}

void readAvailabilityFile(const string &filename, vector<Place> &places)
{
    ifstream availability_file(filename);
    if (!availability_file)
    {
        cerr << "Failed to open availability file." << endl;
        exit(1);
    }

    string line;
    getline(availability_file, line); // ignore header line

    while (getline(availability_file, line))
    {
        istringstream iss(line);
        string placeName, startDateStr, endDateStr;

        if (!(iss >> placeName >> startDateStr >> endDateStr))
        {
            cerr << "Invalid availability file format." << endl;
            exit(1);
        }

        for (size_t i = 0; i < places.size(); ++i)
        {
            if (places[i].name == placeName)
            {
                int startDay, startMonth, endDay, endMonth;
                char delimiter = '.';

                // Parse the start date
                istringstream startDateStream(startDateStr);
                startDateStream >> startDay >> delimiter >> startMonth;

                // Parse the end date
                istringstream endDateStream(endDateStr);
                endDateStream >> endDay >> delimiter >> endMonth;

                // Adjust the day value for June
                if (endMonth == 6)
                {
                    endDay += 31; // June has 30 days
                    startDay += 31;
                }

                // Update the startDate and endDate vectors
                places[i].startDate.push_back(startDay);
                places[i].endDate.push_back(endDay);

                break;
            }
        }
    }

    availability_file.close();
}

void readAssetsFile(const string &filename, vector<Assets> &assets)
{
    ifstream file(filename);
    if (!file)
    {
        cerr << "Failed to open assets file." << endl;
        exit(1);
    }

    string line;
    getline(file, line); // ignore header line

    while (getline(file, line))
    {
        istringstream iss(line);
        Assets asset;

        if (!(iss >> asset.name >> asset.price >> asset.value))
        {
            cerr << "Invalid assets file format." << endl;
            exit(1);
        }

        assets.push_back(asset);
    }
}


/*

                Knapsack algorithm

*/
// maximum of two integers
float getMax(float a, float b)
{
    return (a > b) ? a : b;
}

// Returns the maximum value that can be put in a knapsack of capacity W
vector<vector<float>> knapSack(float W, vector<Assets> &assets)
{
    int n = assets.size();
    vector<vector<float>> M(n + 1, vector<float>(W + 1));

    for (int w = 0; w <= W; w++)
        M[0][w] = 0;

    // Build table M[][] in bottom-up manner
    for (int i = 1; i <= n; i++)
    {
        for (int w = 0; w <= W; w++)
        {
            if (assets[i - 1].price <= w)
                M[i][w] = getMax(M[i - 1][w], assets[i - 1].value + M[i - 1][w - assets[i - 1].price]);
            else
                M[i][w] = M[i - 1][w];
        }
    }

    return M;
}

void writeKnapsack(const vector<vector<float>> &M, float W, int n, const vector<Assets> &assets, const string &caseNumber)
{
    int i = n;
    float k = W;
    float sum = 0;
    vector<string> selectedAssets;

    while (i > 0 && k > 0)
    {
        if (M[i][k] != M[i - 1][k])
        {
            selectedAssets.push_back(assets[i - 1].name);
            sum = sum + assets[i - 1].value;
            k = k - assets[i - 1].price;
        }
        i = i - 1;
    }

    stringstream upgradeListFilePath;
    upgradeListFilePath << "outputs/case_" << caseNumber << "/upgrade_list.txt";
    ofstream outputFile(upgradeListFilePath.str(), ios::out);
    if (!outputFile)
    {
        cerr << "Failed to create output file. (assets)" << endl;
        return;
    }

    outputFile << "Total Value --> " << sum << endl;

    for (size_t i = 0; i < selectedAssets.size(); i++)
    {
        outputFile << selectedAssets[i] << endl;
    }
}


int main(int argc, char *argv[])
{
    if (argc != 2)
    {
        cerr << "Usage: ./program_name <case_number>" << endl;
        return 1;
    }

    //read files

    string caseNumberStr = argv[1];
    stringstream filePathStream;
    filePathStream << "inputs/case_" << caseNumberStr << "/";

    vector<Place> places;

    string capacityFilePath = filePathStream.str() + "capacity.txt";
    readCapacityFile(capacityFilePath, places);

    string dailyScheduleFilePath = filePathStream.str() + "daily_schedule.txt";
    readDailyScheduleFile(dailyScheduleFilePath, places);

    string availabilityFilePath = filePathStream.str() + "availability_intervals.txt";
    readAvailabilityFile(availabilityFilePath, places);

    // Create the case_x folder inside the outputs folder
    createCaseFolder(caseNumberStr);

    stringstream eachPlaceFilePath;
    eachPlaceFilePath << "outputs/case_" << caseNumberStr << "/best_for_eachplace.txt";
    ofstream outputFile(eachPlaceFilePath.str(), ios::out);
    if (!outputFile)
    {
        cerr << "Failed to open output file. (1.)" << endl;
        return 1;
    }
    // Iterate over each place, copy all salons of every place to a new vector that will be used in WIS
    for (Place &place : places)
    {
        outputFile << place.name << " ---> ";
        // Create a new vector and copy all salons into it
        vector<Salon> sortedSalons;

        // Sort the salons by their end time
        // sort(sortedSalons.begin(), sortedSalons.end(), compareSalonByEndTime);
        for (const Salon &salon : place.salons)
        {
            for (size_t i = 0; i < salon.start.size(); i++)
            {
                Salon temp(salon.name, salon.capacity);
                temp.addTime(salon.start[i], salon.end[i]);
                sortedSalons.push_back(temp);
            }
        }
        // Sort the salons by their end time and capacity
        sort(sortedSalons.begin(), sortedSalons.end(), [](const Salon &s1, const Salon &s2)
             {
        if (s1.end != s2.end) {
            return s1.end < s2.end;
        } else {
            return s1.capacity > s2.capacity;
        } });

        // Compute the p array for each sortedSalons
        vector<int> p = computeTimeP(sortedSalons);

        // Initialize the table M
        for (size_t j = 0; j < sortedSalons.size(); j++)
        {
            M[j] = 0;
        }

        // Compute the Mimal solution for each job
        int max_weight = computeTimeM(sortedSalons, p, int(sortedSalons.size()) - 1);
        outputFile << max_weight << endl;

        // set the max_capacity for each place
        place.max_capacity = max_weight;

        findTimeIntervals(outputFile, place.name, sortedSalons, p, int(sortedSalons.size()) - 1);
        outputFile << endl;
    }
    outputFile.close();

    stringstream bestTourFilePath;
    bestTourFilePath << "outputs/case_" << caseNumberStr << "/best_tour.txt";
    ofstream outputFile2(bestTourFilePath.str(), ios::out);
    if (!outputFile2)
    {
        cerr << "Failed to open output file. (2.)" << endl;
        return 1;
    }
    // Create a new vector and copy all places into it
    vector<Place> sortedPlaces;
    outputFile2 << "Total Revenue"
                << " ---> ";
    // Iterate over each place, create a vector of all places with their dates to obtain WIS
    for (Place &place : places)
    {
        // Sort the places by their end time
        for (size_t i = 0; i < place.startDate.size(); i++)
        {
            Place temp(place.name, place.max_capacity * (place.endDate[i] - place.startDate[i]));
            temp.startDate.push_back(place.startDate[i]);
            temp.endDate.push_back(place.endDate[i]);
            sortedPlaces.push_back(temp);
        }
    }

    // Sort the salons by their end time and capacity
    sort(sortedPlaces.begin(), sortedPlaces.end(), [](const Place &p1, const Place &p2)
         { return p1.endDate < p2.endDate; });

    // Compute the p array for each sortedSalons
    vector<int> p = computeDateP(sortedPlaces);

    // Initialize the table M
    for (size_t j = 0; j < sortedPlaces.size(); j++)
    {
        M[j] = 0;
    }

    // Compute the Mimal solution for each job
    int total_revenue = computeDateM(sortedPlaces, p, int(sortedPlaces.size()) - 1);
    outputFile2 << total_revenue << endl;

    findDateIntervals(outputFile2, sortedPlaces, p, int(sortedPlaces.size()) - 1);
    outputFile2 << endl;
    outputFile2.close();
    
    //Knapsack
    vector<Assets> assets;
    string assetsFilePath = filePathStream.str() + "assets.txt";
    readAssetsFile(assetsFilePath, assets);
    vector<vector<float>> M = knapSack(total_revenue, assets);
    writeKnapsack(M, total_revenue, assets.size(), assets, caseNumberStr);
    return 0;
}