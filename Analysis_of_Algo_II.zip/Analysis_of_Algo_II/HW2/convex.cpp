/* @author
Student name: Yasmeen Abdelghany
Student ID: 150190915
Date: 18.04.2023
*/
#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include <sstream>
#include <algorithm>
#include <cmath>
#include <chrono>

using namespace std;

class City
{
public:
    pair<int, int> vertex;
    int cityID;
    void init_city(int x, int y, int cityID)
    {
        this->vertex = make_pair(x, y);
        this->cityID = cityID;
    }
};

class ConvexHull
{
public:
    int n;
    vector<City> &city;

    ConvexHull(int n, vector<City> &city)
        : n(n), city(city) {}

    static bool compare(const City &a, const City &b)
    {
        return (a.vertex.first == b.vertex.first) ? (a.vertex.second < b.vertex.second) : (a.vertex.first < b.vertex.first);
    }

    void sort_x_coord()
    {
        sort(city.begin(), city.end(), compare); // Quicksort algorithm
    }

    /**
    This function divides a vector of City objects into subsets using the median-of-medians algorithm, and adds each subset to a vector of vector of City objects.
    If a subset has 3 or fewer cities, it is added to the output subset vector. If a subset has more than 3 cities, it is recursively divided using the median-of-medians algorithm.
    @param subset A vector of vector of City objects that will contain the output subsets.
    @param city A vector of City objects to be divided into subsets.
    */
    void median_of_Medians(vector<vector<City>> &subset, vector<City> &city)
    {
        int n = city.size();

        // Divide the cities into groups of 5 and find the median of each group -> it is already sorted
        vector<City> medians;
        for (int i = 0; i < n; i += 5)
        {
            vector<City> group;
            for (int j = i; j < i + 5 && j < n; j++)
            {
                group.push_back(city[j]);
            }
            medians.push_back(group[(group.size() - 1) / 2]);
        }

        // Find the median of medians
        City medianOfMedians = medians[((medians.size() - 1) / 2)];
        int medianIndex = -1;
        for (int i = 0; i < n; i++)
        {
            if (city[i].vertex == medianOfMedians.vertex)
            {
                medianIndex = i;
                break;
            }
        }

        // Divide the input cities into two subsets based on the median index
        vector<City> leftSubset(city.begin(), city.begin() + medianIndex + 1);
        vector<City> rightSubset(city.begin() + medianIndex + 1, city.end());

        // If the left subset has 3 or fewer cities, add it to the output subset vector
        if (int(leftSubset.size()) <= 3)
        {
            // If the subset has 3 cities and is not in counterclockwise order, swap the second and third cities
            if (leftSubset.size() == 3 && !is_CCW(leftSubset[0], leftSubset[1], leftSubset[2]))
            {
                swap(leftSubset[1], leftSubset[2]);
            }
            // Add the subset to the output vector
            subset.push_back(leftSubset);
        }
        // Otherwise, recursively divide the left subset using the median-of-medians algorithm
        else
        {
            median_of_Medians(subset, leftSubset);
        }
        // If the right subset has 3 or fewer cities, add it to the output subset vector
        if (int(rightSubset.size()) <= 3)
        {
            // If the subset has 3 cities and is not in counterclockwise order, swap the second and third cities
            if (rightSubset.size() == 3 && !is_CCW(rightSubset[0], rightSubset[1], rightSubset[2]))
            {
                swap(rightSubset[1], rightSubset[2]);
            }
            // Add the subset to the output vector
            subset.push_back(rightSubset);
        }
        // Otherwise, recursively divide the right subset using the median-of-medians algorithm
        else
        {
            median_of_Medians(subset, rightSubset);
        }
    }

    // If the cross product is positive, the orientation is counter-clockwise.
    bool is_CCW(const City &A, const City &B, const City &C)
    {
        double crossProduct = (B.vertex.first - A.vertex.first) * (C.vertex.second - A.vertex.second) - (C.vertex.first - A.vertex.first) * (B.vertex.second - A.vertex.second);
        return crossProduct > 0;
    }

    // This function takes four cities and returns a boolean value indicating if the two cities prev and next , is below the line formed by the two extreme cities, lmax and rmin.
    bool is_below_line(City lmax, City rmin, City prev, City next)
    {
        // Calculate the slope and intercept of the line formed by lmax and rmin.
        double m = static_cast<double>(rmin.vertex.second - lmax.vertex.second) / (rmin.vertex.first - lmax.vertex.first);
        double b = (lmax.vertex.second - m * lmax.vertex.first);
        bool below = false;
        // Determine if the points prev and next are below the line formed by lmax and rmin.
        if (prev.vertex.second <= m * prev.vertex.first + b && next.vertex.second <= m * next.vertex.first + b) // should it be >=?
        {
            below = true;
        }

        return below;
    }
    // This function takes four cities and returns a boolean value indicating if the two cities prev and next , is above the line formed by the two extreme cities, lmax and rmin.
    bool is_above_line(City lmax, City rmin, City prev, City next)
    {
        // Calculate the slope and intercept of the line formed by lmax and rmin.
        double m = static_cast<double>(rmin.vertex.second - lmax.vertex.second) / (rmin.vertex.first - lmax.vertex.first);
        double b = (lmax.vertex.second - (m * lmax.vertex.first));
        bool below = false;
        // Determine if the points prev and next are above the line formed by lmax and rmin.
        if (prev.vertex.second >= m * prev.vertex.first + b && next.vertex.second >= m * next.vertex.first + b) // should it be >=?
        {
            below = true;
        }

        return below;
    }

    /**
    This function finds the upper tangent between two sets of cities.
    It takes in two vectors of cities, 'left' and 'right', representing the left and right subsets respectively.
    It first finds the city with the maximum x-coordinate in the left subset and the city with the minimum x-coordinate in the right subset.
    Then, it iteratively moves the left and right tangents clockwise until they form a valid upper tangent between the two subsets.
    Finally, it returns the indices of the cities in the left and right subsets that form the upper tangent as a pair of integers.
    */
    pair<int, int> find_upper(vector<City> left, vector<City> right)
    {
        int lmax = 0, rmin = 0;
        // Find the city with the maximum x-coordinate in the left subset
        for (int i = 1; i < int(left.size()); i++)
        {
            if (left[i].vertex.first > left[lmax].vertex.first)
                lmax = i;
        }
        // Find the city with the minimum x-coordinate in the right subset
        for (int i = 1; i < int(right.size()); i++)
        {
            if (right[i].vertex.first < right[rmin].vertex.first)
                rmin = i;
        }

        bool valid = 0;
        while (!valid)
        {
            valid = 1;
            // Move the left tangent counterclockwise until it forms a valid tangent with the right subset
            City prev = left[(left.size() + lmax - 1) % left.size()]; //each vector is oriented in a ccw manner
            City next = left[(lmax + 1) % left.size()];
            while (!is_below_line(left[lmax], right[rmin], prev, next))
            {
                lmax = (lmax + 1) % left.size();
                prev = left[(left.size() + lmax - 1) % left.size()];
                next = left[(lmax + 1) % left.size()];
            }
            // Move the right tangent clockwise until it forms a valid tangent with the left subset
            next = right[(right.size() + rmin - 1) % right.size()]; //each vector is oriented in a ccw manner
            prev = right[(rmin + 1) % right.size()];
            while (!is_below_line(left[lmax], right[rmin], prev, next))
            {
                rmin = (right.size() + rmin - 1) % right.size();
                next = right[(right.size() + rmin - 1) % right.size()];
                prev = right[(rmin + 1) % right.size()];
                valid = 0;
            }
        }

        return make_pair(lmax, rmin);
    }
    /**
    This function finds the lower tangent between two sets of cities.
    It takes in two vectors of cities, 'left' and 'right', representing the left and right subsets respectively.
    It first finds the city with the maximum x-coordinate in the left subset and the city with the minimum x-coordinate in the right subset.
    Then, it iteratively moves the left and right tangents clockwise until they form a valid lower tangent between the two subsets.
    Finally, it returns the indices of the cities in the left and right subsets that form the lower tangent as a pair of integers.
    */
    pair<int, int> find_lower(vector<City> left, vector<City> right)
    {
        int lmax = 0, rmin = 0;
        // Find the city with the maximum x-coordinate in the left subset
        for (int i = 1; i < int(left.size()); i++)
        {
            if (left[i].vertex.first > left[lmax].vertex.first)
                lmax = i;
        }
        // Find the city with the minimum x-coordinate in the right subset
        for (int i = 1; i < int(right.size()); i++)
        {
            if (right[i].vertex.first < right[rmin].vertex.first)
                rmin = i;
        }

        bool valid = 0;
        while (!valid)
        {
            valid = 1;
            // Move the right tangent counterclockwise until it forms a valid tangent with the left subset
            City next = right[(right.size() + rmin - 1) % right.size()]; //each vector is oriented in a ccw manner
            City prev = right[(rmin + 1) % right.size()];
            while (!is_above_line(left[lmax], right[rmin], prev, next))
            {
                rmin = (rmin + 1) % right.size();
                next = right[(right.size() + rmin - 1) % right.size()];
                prev = right[(rmin + 1) % right.size()];
            }
            // Move the left tangent clockwise until it forms a valid tangent with the right subset
            prev = left[(left.size() + lmax - 1) % left.size()]; //each vector is oriented in a ccw manner
            next = left[(lmax + 1) % left.size()];
            while (!is_above_line(left[lmax], right[rmin], prev, next))
            {
                lmax = (left.size() + lmax - 1) % left.size();
                prev = left[(left.size() + lmax - 1) % left.size()];
                next = left[(lmax + 1) % left.size()];
                valid = 0;
            }
        }

        return make_pair(lmax, rmin);
    }

    // Merges two convex polygons into a single convex polygon
    vector<City> merge_polygons(const vector<City> left, const vector<City> right)
    {
        // Find the upper and lower tangent points between the two polygons
        pair<int, int> upperPoints;
        upperPoints = find_upper(left, right);
        pair<int, int> lowerPoints;
        lowerPoints = find_lower(left, right);

        // Create a vector to store the merged polygon
        vector<City> hull;

        // Traverse the left polygon from the starting point to the lower tangent point and add its vertices to the merged polygon
        int start = 0;
        hull.push_back(left[start]);
        while (start != lowerPoints.first)
        {
            start = (start + 1) % left.size();
            hull.push_back(left[start]);
        }
        // Traverse the right polygon from the lower tangent point to the upper tangent point and add its vertices to the merged polygon
        start = lowerPoints.second;
        hull.push_back(right[start]);
        while (start != upperPoints.second)
        {
            start = (start + 1) % right.size();
            hull.push_back(right[start]);
        }
        // Traverse the left polygon from the upper tangent point to the starting point and add its vertices to the merged polygon
        start = upperPoints.first;
        hull.push_back(left[start]);
        while (start != 0)
        {
            start = (start + 1) % left.size();
            hull.push_back(left[start]);
        }
        // Remove the last vertex in the merged polygon - the duplicate of the first vertex
        hull.pop_back();
        return hull;
    }

    /*
    This function writes the convex hull to a file named "convex.txt".
    It takes a vector of City objects representing the convex hull as input.
    The output file contains the number of vertices of the convex hull and a string
    representing the counterclockwise order of the vertices.
    If three consecutive vertices are collinear, the middle vertex is skipped.
    */
    void write_file(vector<City> hull)
    {
        ofstream outfile("convex.txt", ios::out); // Open a txt file named "convex"
        int size = hull.size();
        // Initialize a string to store the counterclockwise order of the vertices
        string ccw_path = "";
        for (int i = 0; i < int(hull.size()); i++)
        {
            // Get the coordinates of the three consecutive vertices
            int prevX = hull[(i - 1 + hull.size()) % hull.size()].vertex.first;
            int prevY = hull[(i - 1 + hull.size()) % hull.size()].vertex.second;
            int currX = hull[i].vertex.first;
            int currY = hull[i].vertex.second;
            int nextX = hull[(i + 1) % hull.size()].vertex.first;
            int nextY = hull[(i + 1) % hull.size()].vertex.second;
            // Check if the three vertices are collinear
            if ((prevY - currY) * (prevX - nextX) == (prevY - nextY) * (prevX - currX))
            {
                // Skip the middle point if the three points are collinear -> as it is done in all given cases
                size--;
                continue;
            }
             // Append the ID of the current vertex to the counterclockwise path
            ccw_path += to_string(hull[i].cityID) + "->";
        }
        // Append the ID of the first vertex to complete the counterclockwise path
        ccw_path += to_string(hull[0].cityID);

        outfile << size << endl;
        outfile << ccw_path << endl;

        outfile.close();
    }
    //Merges a vector of convex hull subsets to create the final convex hull of all the cities.
    void merge(vector<vector<City>> subset)
    {   
        // Merges the first two subsets to obtain a partial convex hull.
        vector<City> hull = merge_polygons(subset[0], subset[1]);

        // Merges all other subsets to complete the convex hull.
        for (int i = 2; i < int(subset.size()); i++)
        {
            hull = merge_polygons(hull, subset[i]);
        }
        // Writes the final convex hull to a file.
        write_file(hull);
    }
};

int main(int argc, char *argv[]) //
{
    /*
        Keep your solution for Convex Hull Part in this file!
        Program Compile Command: g++ -std=c++11 -Wall -Werror conve.cpp -o convex
        Program Run Command: ./convex <input.txt>
        Expected input: /cases/case{$n}/input{$n}.txt
        Expected output: convex.txt
        Please, try to write clean and readable code. Remember to comment!!
    */

    try
    {
        if (argc < 2)
        {
            throw "You must enter the file name!";
        }
    }
    catch (const exception &e)
    {
        cerr << e.what() << '\n';
    }

    string fileName = argv[1]; ////  //
    fstream myFile;
    int n = 0; // No. of cities
    vector<City> city;

    //read from the file
    try
    {
        myFile.open(fileName, ios::in); // ios::in for reading from file
        if (myFile.fail())
        {
            throw "Couldn't open/find the file\n";
        }
        float th = 0; // threshold
        int k = 0;    // no. of bakeries
        myFile >> n >> k >> th;
        city.resize(n);

        for (int i = 0; i < k; i++)
        {
            int source = 0;
            myFile >> source;
        }

        for (int i = 0; i < n; i++)
        {
            int x, y, a;
            myFile >> x >> y >> a; // read x, y, and a values from the file
            city[i].init_city(x, y, i);
        }
        myFile.close();
    }
    catch (const char *e)
    {
        cerr << e << endl;
        std::exit(1);
    }
    auto begin = chrono::high_resolution_clock::now(); // start clock

    ConvexHull convexHull(n, city);
    
    // Sort the cities by x coordinate
    convexHull.sort_x_coord();

    // Divide the cities into subsets and compute their convex hulls
    vector<vector<City>> subset;
    convexHull.median_of_Medians(subset, city);

    // Merge the convex hulls of the subsets into a single convex hull and then call the write function to output the hull to the file
    convexHull.merge(subset);

    auto end = chrono::high_resolution_clock::now(); // end clock
    double run_time = chrono::duration_cast<chrono::duration<double>>(end - begin).count();
    cout << "Run Time: " << run_time << endl;
    cout << "Cities: " << n << endl;
    std::exit(0);
}