/* @author
Student name: Yasmeen Abdelghany
Student ID: 150190915
Date: 18.04.2023
*/
#include <iostream>
#include <string>
#include <vector>
#include <queue>
#include <fstream>
#include <sstream>
#include <algorithm>
#include <cmath>
#include <chrono>

using namespace std;

class City
{
public:
    int cityID;
    int a;
    void init_city(int cityID, int a)
    {
        this->cityID = cityID;
        this->a = a;
    }
};

struct CustomCompare
{
    bool operator()(const pair<int, int> &p1, const pair<int, int> &p2) const
    {
        return p1.second == p2.second ? p1.first < p2.first : p1.second < p2.second;
    }
};

class Graph
{
public:
    int n;                                 // number of vertices
    vector<vector<pair<int, double>>> adj; // adjacency list
    double threshold;

    Graph(int n, double threshold)
    {
        this->n = n;
        this->threshold = threshold;
        adj.resize(n);
    }

    // add edge between two cities if the plow number is less than or equal to the threshold * mean_pount
    void addEdge(City c1, City c2)
    {
        double plow = abs(c1.a - c2.a);
        double mean_pount = (c1.a + c2.a) / 2.0;
        if (plow && plow <= threshold * mean_pount)
        {
            adj[c1.cityID].push_back(make_pair(c2.cityID, plow));
            adj[c2.cityID].push_back(make_pair(c1.cityID, plow)); // since the graph is undirected
        }
    }

    // build the graph based on the cities and their plow numbers
    void buildGraph(vector<City> city)
    {
        for (int i = 0; i < n; i++)
        {
            for (int j = i + 1; j < n; j++)
            {
                addEdge(city[i], city[j]);
            }
        }
    }

    void primAlgorithm(int n, int k, vector<int> bakery_source, vector<City> &city, vector<vector<int>> &k_branchlist)
    {

        // Initialize variables
        vector<int> visited(n, -1);                                                             // mark all cities as unvisited
        vector<priority_queue<pair<int, int>, vector<pair<int, int>>, CustomCompare>> edges(k); // create a priority queue for each bakery's branch
        bool is_done[k];                                                                        // array to mark whether a branch has been exhausted
        fill_n(is_done, k, false);
        bool all_visited[k]; // array to mark whether all cities have been visited for a particular branch
        fill_n(all_visited, k, false);
        bool end = false; // flag to signal when to stop the algorithm

        // Initialize the branches with the source cities of each bakery
        for (int i = 0; i < k; i++)
        {
            k_branchlist[i].push_back(bakery_source[i]); // add the bakery's source city to its branch
            visited[bakery_source[i]] = 1;               // mark the source city as visited
        }

        // Run the algorithm until all branches have been exhausted
        while (!end)
        {
            // Loop over all bakeries' branches
            for (int bakery = 0; bakery < k; bakery++)
            {
                int id = k_branchlist[bakery].back(); // get the last city visited in the branch
                bool no_next = true;
                for (int j = 0; j < int(adj[id].size()); j++)
                {
                    // Only consider unvisited cities
                    if (visited[adj[id][j].first] == 1)
                    {
                        continue;
                    }
                    else
                    {
                        adj[id][j].first *= -1;         // negate the city ID to sort by descending order of edge weight
                        edges[bakery].push(adj[id][j]); // add the edge to the bakery's priority queue
                        no_next = false;
                    }
                }

                // Check if there are no more unvisited adjacent cities
                if (no_next)
                {
                    all_visited[bakery] = true; // mark the bakery's recent branch as exhausted -> recent branch has no other adj unvisited cities
                }

                // Add the city with the heaviest edge weight to the bakery's branch
                int id_maxW = 0;
                if (!edges[bakery].empty())
                {
                    id_maxW = edges[bakery].top().first * -1; // get the city ID with the heaviest edge weight
                    k_branchlist[bakery].push_back(id_maxW);  // add the city to the bakery's branch
                    visited[id_maxW] = 1;                     // mark the city as visited
                    edges[bakery].pop();                     // remove the heaviest edge from the bakery's priority queue
                }
                // Check if the bakery's branch is exhausted -> no more branches will open for this bakery
                else if (edges[bakery].empty() && all_visited[bakery])
                {
                    is_done[bakery] = true; // mark the bakery's branch as exhausted
                }

                int all_branches_done = 0;
                for (int i = 0; i < k; i++)
                {
                    if (!edges[i].empty())
                    {
                        int id1 = edges[i].top().first * -1; // get the city ID with the heaviest weight in the priority queue
                        if (visited[id1] == 1)
                        {
                            edges[i].pop(); // remove the edge if the city has already been visited
                            i--;            // decrement i to account for the removed edge
                            continue;
                        }
                    }
                    if (edges[i].empty() && is_done[i])
                    {
                        all_branches_done++; // increment the number of full branches
                    }
                }

                if (all_branches_done == k) // if all branches are exhausted, end program
                {
                    end = true; // set the flag to end the algorithm
                }
            }
        }
    }
};

int main(int argc, char *argv[]) //
{
    /*
        Keep your solution for Prim's algorithm Part in this file!
        Program Compile Command: g++ -std=c++11 -Wall -Werror prim.cpp -o prim
        Program Run Command: ./prim <input.txt>
        Expected input: /cases/case{$n}/input{$n}.txt
        Expected output: prim.txt
        Please, try to write clean and readable code. Remember to comment!!
    */
    try
    {
        if (argc < 2)
        {
            throw "You must enter the file name!";
        }
    }
    catch (const exception &e)
    {
        cerr << e.what() << '\n';
    }

    string fileName = argv[1]; //"cases/case03/input03.txt"; //  ////  //
    fstream myFile;
    int n = 0;    // No. of cities
    float th = 0; // threshold
    int k = 0;    // no. of bakeries
    vector<City> city;
    vector<int> bakery_source;
    try
    {
        myFile.open(fileName, ios::in); // ios::in for reading from file
        if (myFile.fail())
        {
            throw "Couldn't open/find the file\n";
        }

        myFile >> n >> k >> th;
        city.resize(n);

        for (int i = 0; i < k; i++)
        {
            int source = 0;
            myFile >> source;
            bakery_source.push_back(source);
        }

        for (int i = 0; i < n; i++)
        {
            int x, y, a;
            myFile >> x >> y >> a; // read x, y, and a values from the file
            city[i].init_city(i, a);
        }
        myFile.close();
    }
    catch (const char *e)
    {
        cerr << e << endl;
        exit(1);
    }
    auto begin = chrono::high_resolution_clock::now(); // start clock
    Graph graph(n, th);
    graph.buildGraph(city);
    vector<vector<int>> k_branchlist(k);

    graph.primAlgorithm(n, k, bakery_source, city, k_branchlist);

    ofstream outfile("prim.txt", ios::out); // Open a txt file named "prim"
    for (int i = 0; i < k; i++)
    {
        outfile << "k" << i << " " << k_branchlist[i].size() << endl;
        for (int j = 0; j < int(k_branchlist[i].size()); j++)
        {
            outfile << k_branchlist[i][j];
            if (j < int(k_branchlist[i].size()) - 1)
            {
                outfile << "->";
            }
        }
        outfile << endl;
    }
    auto end = chrono::high_resolution_clock::now(); // end clock
    double run_time = chrono::duration_cast<chrono::duration<double>>(end - begin).count();
    cout << "Run Time: " << run_time << endl;
    cout << "Cities: " << n << endl;
    exit(0);
}